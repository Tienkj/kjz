from flask import Flask, jsonify, request, send_file, render_template
import datetime
import time
import threading
import os
from pcomfortcloud import Session, ApiClient

USERNAME = "tiendathmfa@gmail.com"
PASSWORD = "Tien6kjaz"
DEVICE_INDEX = 0  # số thứ tự của thiết bị

LOG_FILE = "temperature_log.txt"
FETCH_INTERVAL = 2 * 60 * 60  # 2 tiếng

app = Flask(__name__, template_folder='templates', static_folder='static')


def get_temperature():
    session = Session(USERNAME, PASSWORD)
    session.login()
    client = ApiClient(session)
    devices = client.get_devices()
    data = client.get_device(devices[DEVICE_INDEX]['id'])

    inside = data['parameters'].get('temperatureInside', -1)
    outside = data['parameters'].get('temperatureOutside', -1)

    return inside, outside


def log_temperature():
    while True:
        now = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
        inside, outside = get_temperature()
        with open(LOG_FILE, "a") as f:
            f.write(f"{now} | Nhiệt độ trong: {inside}°C | Ngoài: {outside}°C\n")
        time.sleep(FETCH_INTERVAL)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/data")
def get_data():
    search_date = request.args.get("date")

    # Lấy ngày hiện tại nếu không có ngày tìm kiếm
    if not search_date:
        today = datetime.datetime.now().strftime("%d/%m/%Y")
        search_date = today  # Mặc định tìm theo ngày hôm nay

    with open(LOG_FILE, "r") as f:
        lines = f.readlines()

    filtered = [line.strip() for line in lines if search_date in line]

    return jsonify(filtered)


@app.route("/text")
def get_text_file():
    return send_file(LOG_FILE, as_attachment=False)


if __name__ == "__main__":
    if not os.path.exists(LOG_FILE):
        open(LOG_FILE, "w").close()
    threading.Thread(target=log_temperature, daemon=True).start()
    app.run(host="0.0.0.0", port=5000)
