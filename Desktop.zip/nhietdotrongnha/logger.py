import pcomfortcloud
import datetime
import json

# Đăng nhập vào tài khoản
session = pcomfortcloud.Session('tiendathmfa@gmail.com', 'Tien6kjaz')
session.login()

# Khởi tạo client và lấy thiết bị
client = pcomfortcloud.ApiClient(session)
devices = client.get_devices()

# Lấy thông tin của thiết bị đầu tiên
device_id = devices[0]['id']
device_info = client.get_device(device_id)

# Lấy nhiệt độ trong nhà và ngoài trời
inside_temp = device_info['parameters']['temperatureInside']
outside_temp = device_info['parameters']['temperatureOutside']

# Lấy ngày và giờ hiện tại
now = datetime.datetime.now()
current_date = now.strftime('%Y-%m-%d')
current_time = now.strftime('%H:%M')

# Ghi dữ liệu vào file JSON
data = {
    'date': current_date,
    'time': current_time,
    'inside_temperature': inside_temp,
    'outside_temperature': outside_temp
}

# Đường dẫn tệp để lưu dữ liệu
log_file = 'temperature_log.json'

# Kiểm tra nếu file tồn tại và ghi dữ liệu
try:
    with open(log_file, 'r') as f:
        logs = json.load(f)
except FileNotFoundError:
    logs = []

logs.append(data)

with open(log_file, 'w') as f:
    json.dump(logs, f, indent=4)

print(f"Đã ghi dữ liệu: {data}")
